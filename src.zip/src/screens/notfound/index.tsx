export default function Notfound() {
    return <>
        <div>
            <h1>Notfound</h1>
        </div>
    </>
}